# bitcoin original sources

archive of original bitcoin material

On Sat, 01 Nov 2008 16:16:33 -0700 Satoshi Nakamoto posted the whitepaper bitcoin.pdf. (md5sum d56d71ecadf2137be09d8b1d35c6c042).

On Thu Jan 8 14:27:40 EST 2009 the first version was released. (md5sum dca1095f053a0c2dc90b19c92bd1ec00 ). http://www.metzdowd.com/pipermail/cryptography/2009-January/014994.html.

In november 2008 some sources were distributed privately

"This is the Bitcoin sources from November 16, 2008 - a few months before the current blockchain began.". "I was on the Metzdowd cryptography list at that time.", https://bitcointalk.org/index.php?topic=382374.0 

the private november 2008 version is in the nov08 folder.

the study folder contains the main files of the 0.1 version, roughly 7000 LOC.

*  2660 ./main.cpp
*  1127 ./script.cpp
*  1020 ./net.cpp
*   604 ./db.cpp
*   554 ./sha.cpp
*   373 ./util.cpp
*   265 ./irc.cpp
*  6603 total